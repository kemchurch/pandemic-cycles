function y = ChebyshevT(n,x)
y = cos(n*acos(x));
end